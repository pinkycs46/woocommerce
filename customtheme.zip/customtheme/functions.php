<?php

function register_header_menu() {
    register_nav_menu('header-menu', 'Header Menu');
}

add_action('after_setup_theme', 'register_header_menu');


function custom_theme_assets() {
	wp_enqueue_style( 'style', get_stylesheet_uri() );
}

add_action( 'wp_enqueue_scripts', 'custom_theme_assets' );

add_theme_support('post-thumbnails');

add_action('init', 'custom_post_type');

function custom_post_type() {
    $labels = array(
        'name'               => _x('Listing', 'post type general name', 'your-text-domain'),
        'singular_name'      => _x('Listing', 'post type singular name', 'your-text-domain'),
        'menu_name'          => _x('Listing', 'admin menu', 'your-text-domain'),
        'name_admin_bar'     => _x('Listing', 'add new on admin bar', 'your-text-domain'),
        'add_new'            => _x('Add New', 'custom post', 'your-text-domain'),
        'add_new_item'       => __('Add New Listing', 'your-text-domain'),
        'new_item'           => __('New Listing', 'your-text-domain'),
        'edit_item'          => __('Edit Listing', 'your-text-domain'),
        'view_item'          => __('View Listing', 'your-text-domain'),
        'all_items'          => __('All Listing', 'your-text-domain'),
        'search_items'       => __('Search Listing', 'your-text-domain'),
        'parent_item_colon'  => __('Parent Listing:', 'your-text-domain'),
        'not_found'          => __('No custom list found.', 'your-text-domain'),
        'not_found_in_trash' => __('No custom list found in Trash.', 'your-text-domain'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'menu_icon'          => 'dashicons-calendar',
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( "slug" => "listing", "with_front" => true ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 11,     
        'supports'           => array( "title", "editor", "thumbnail", "page-attributes", "post-formats" ),
    );

    register_post_type('listing', $args);

    $labels = array(
      'name'              => _x( 'Categories', 'taxonomy general name' ),
      'singular_name'     => _x( 'Category', 'taxonomy singular name' ),
      'search_items'      => __( 'Search Category' ),
      'all_items'         => __( 'All Categories' ),
      'parent_item'       => __( 'Parent Category' ),
      'parent_item_colon' => __( 'Parent Category:' ),
      'edit_item'         => __( 'Edit Category' ),
      'update_item'       => __( 'Update Category' ),
      'add_new_item'      => __( 'Add New Category' ),
      'new_item_name'     => __( 'New Category Name' ),
      'menu_name'         => __( 'Category' ),
   );

    $args = array(
      'hierarchical'      => true,
      'labels'            => $labels,
      'show_ui'           => true,
      'show_admin_column' => true,
      'query_var'         => true,
      'rewrite'           => array( 'slug' => 'list_category' ),
   );

   register_taxonomy( 'list_category', array( 'listing' ), $args );
}



function add_custom_meta_box() {
    add_meta_box(
        'order_meta_box',
        __('Order', 'textdomain'),
        'display_order_meta_box',
        'listing', // Custom post type name
        'normal',
        'high'
    );

    add_meta_box(
        'city_meta_box',      // Unique ID
        'City',              
        'display_city_meta_box',
        'listing',  // Post type
        'normal',             
        'high'                
    );


    add_meta_box(
        'rating_meta_box',       // Unique ID
        'Rating',                
        'display_rating_meta_box', 
        'listing',  // Post type
        'normal',                
        'high'                  
    );
    
}

add_action('add_meta_boxes', 'add_custom_meta_box');

function display_order_meta_box($post) {
    // Retrieve existing values from the database
    $order_value = get_post_meta($post->ID, '_order_value', true);

    // HTML for the meta box
    ?>
    <label for="order_value"><?php _e('Order Value:', 'textdomain'); ?></label>
    <input type="text" name="order_value" id="order_value" value="<?php echo esc_attr($order_value); ?>" />
    <?php
}

// Display the meta box content
function display_city_meta_box($post) {
    // Retrieve existing value from the database
    $city = get_post_meta($post->ID, '_city', true);

    // Nonces are used to verify that the authentication key isn't being spoofed
    wp_nonce_field('city_meta_box_nonce', 'city_meta_box_nonce');

    // Display the form, using the current value
    ?>
    <p>
        <label for="city">City:</label>
        <input type="text" id="city" name="city" value="<?php echo esc_attr($city); ?>" />
    </p>
    <?php
}

// Display the meta box content
function display_rating_meta_box($post) {
    // Retrieve existing value from the database
    $rating = get_post_meta($post->ID, '_rating', true);

    // Nonces are used to verify that the authentication key isn't being spoofed
    wp_nonce_field('rating_meta_box_nonce', 'rating_meta_box_nonce');

    // Display the form, using the current value
    ?>
    <p>
        <label for="rating">Rating:</label>
        <input type="number" id="rating" name="rating" min="1" max="5" step="0.1" value="<?php echo esc_attr($rating); ?>" />
    </p>
    <?php
}

function save_order_meta_box_data($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

     // Check if the current user has permission to save the post
     if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['order_value'])) {
        update_post_meta($post_id, '_order_value', sanitize_text_field($_POST['order_value']));
    }


    // Check if the nonce is set
    if (!isset($_POST['city_meta_box_nonce'])) {
        return;
    }

    // Verify that the nonce is valid
    if (!wp_verify_nonce($_POST['city_meta_box_nonce'], 'city_meta_box_nonce')) {
        return;
    }

    // Save the city
    if (isset($_POST['city'])) {
        update_post_meta($post_id, '_city', sanitize_text_field($_POST['city']));
    }


    // Check if the nonce is set
    if (!isset($_POST['rating_meta_box_nonce'])) {
        return;
    }

    // Verify that the nonce is valid
    if (!wp_verify_nonce($_POST['rating_meta_box_nonce'], 'rating_meta_box_nonce')) {
        return;
    }

    // Save the rating
    if (isset($_POST['rating'])) {
        $rating = floatval($_POST['rating']);
        update_post_meta($post_id, '_rating', $rating);
    }
}

add_action('save_post', 'save_order_meta_box_data');
