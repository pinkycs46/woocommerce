<?php
get_header();

$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

$args = array(
    'post_type'      => 'listing',
    'post_status'    => 'publish',
    'posts_per_page' => 5,
    'paged'          => $paged,
    'meta_key'       => '_order_value',
    'orderby'        => 'meta_value_num',
    'order'          => 'DESC',
);

$custom_query = new WP_Query($args);

if ($custom_query->have_posts()) :
    ?>
<div class="post-container">
    <h2 style="margin-bottom: 25px;font-size: 35px;font-weight: 600;color: #333;">Events</h2>
    <?php
    // Output pagination links
    echo '<div class="pagination">';
    echo paginate_links(array(
        'total'     => $custom_query->max_num_pages,
        'current'   => max(1, get_query_var('paged')),
        'prev_text' => __('&laquo; Previous'),
        'next_text' => __('Next &raquo;'),
    ));
    echo '</div>';
    while ($custom_query->have_posts()) {
        $custom_query->the_post();
        $postid         = get_the_ID();
        $title          = get_the_title();
        $event_desc     = get_the_content();
        $event_address  = get_post_meta(get_the_ID(), '_city', true);
        $rate           = get_post_meta(get_the_ID(), '_rating', true);
        $publish_date   = get_the_date();
        $featured_image = get_the_post_thumbnail(null, 'medium');
        ?>
        
        <div id="post-<?php echo $postid; ?>" class="magento-event-article">
            <div class="magento-events-list">
                <ul>
                    <li class="event-list">
                        <?php
                        if (has_post_thumbnail()) {
                            $src = wp_get_attachment_image_src(get_post_thumbnail_id($postid), 'medium_large', true);
                            ?>
                            <img src="<?php echo $src[0]; ?>" alt="Event Image" class="event-image">
                            <?php
                        }
                        ?>
                        <div class="event-info">
                            <h3 class="title"><?php echo $title; ?></h3>
                            <p><?php echo $event_desc; ?></p>
                            <div class="event-detail">
                                <div class="icon">
                                    <span class="dashicons dashicons-location"></span>
                                </div>
                                <div class="text"><strong>Venue</strong></div>
                                <div class="description">
                                    <p><?php echo $event_address; ?></p>
                                </div>
                            </div>
                            <div class="event-detail">
                                <div class="icon">
                                    <span class="dashicons dashicons-heart"></span>
                                </div>
                                <div class="description">
                                    <p><?php echo $rate; ?></p>
                                </div>
                            </div>
                            <div class="fusion-meta-info">
                                <div class="fusion-alignright">
                                    <a href="#" aria-label="Read More About-" class="fusion-read-more more-details" title="<?php echo $title; ?>" target="_blank" rel="noopener noreferrer nofollow" tabindex="0" role="link">More Details</a>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <?php

    }
    // Output pagination links
    echo '<div class="pagination">';
    echo paginate_links(array(
        'total'     => $custom_query->max_num_pages,
        'current'   => max(1, get_query_var('paged')),
        'prev_text' => __('&laquo; Previous'),
        'next_text' => __('Next &raquo;'),
    ));
    echo '</div>';

    wp_reset_postdata();
else :
    echo 'No listings found.';
endif;
?>
</div>
<?php
get_footer();
?>
