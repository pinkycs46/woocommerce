<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <title><?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <div class="container">
        <header class="site-header">
            <!-- Get the URL of the theme's directory -->
            <?php $theme_directory = get_template_directory_uri(); ?>

            <!-- Replace 'images/logo-2.png' with the relative path to your logo -->
            <div class="header-logo">
                <img src="<?php echo $theme_directory . '/images/logo-2.png'; ?>" alt="Site Logo">
            </div>

            <div class="header-desc">
                <h1><a href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a></h1>
                <h4><?php bloginfo('description'); ?></h4>
            </div>

            <nav class="site-navigation">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'header-menu', // Add this menu in your functions.php file
                    'container'      => false,
                    'menu_class'     => 'site-menu',
                    'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                ));
                ?>
            </nav>
        </header>
    </div>
    <?php wp_footer(); ?>
</body>

</html>
