<footer class="site-footer">
    <div class="footer-container">
        <div class="contact-info">
            <h3>Contact Us</h3>
            <p>Email: info@example.com</p>
            <p>Phone: +123 456 7890</p>
            <p>Address: 123 Street, City, Country</p>
        </div>
        <div class="copyright-info">Copyright
            <!-- <img src="path/to/copyright-logo.png" alt="Copyright Logo"> -->
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
        </div>
    </div>
</footer>
</div> <!-- closes <div class="container"> -->

<?php wp_footer(); ?>
</body>
</html>
