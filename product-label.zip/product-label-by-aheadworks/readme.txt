=== Product Labels By Aheadworks ===
Contributors: Rave Digital
Tags: product labels, woocommerce
Requires at least: 5.4.7
Tested up to: 5.8.1

Stable tag: trunk
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Product Labels for WooCommerce.

== Description ==

Product Labels By Aheadworks for WooCommerce. Show promotions with product labels.

== Installation ==

Here are some things to know before you begin this process.
- This plugin requires you to have the [WooCommerce plugin](https://woocommerce.com/) already installed and activated in WordPress.
- Your hosting environment must meet [WooCommerce's minimum requirements](https://docs.woocommerce.com/document/server-requirements), including PHP 7.0 or greater.
- Make sure to update Permalinks under Admin Settings Menu. (Just open Permalinks Page and click "Save Changes" button)

== Changelog ==

Version 1.0.0 - Initial release of plugin.