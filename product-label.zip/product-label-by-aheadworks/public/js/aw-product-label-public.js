var nonce_pl  = js_pl_var.aw_pl_nonce;
var url    = js_pl_var.site_url;
