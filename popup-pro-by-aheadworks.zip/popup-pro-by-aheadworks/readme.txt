=== Popup Pro By Aheadworks ===
Contributors: Rave Digital
Tags: popup, woocommerce
Requires at least: 4.9.8
Tested up to: 5.3.2
Stable tag: trunk
Requires PHP: 7.0
WC tested up to: 3.9
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Popup pro By Aheadworks for WooCommerce. Show promotions with popups.

== Description ==

Popup pro By Aheadworks for WooCommerce. Show promotions with popups.
<strong>Features:</strong>


== Installation ==

Here are some things to know before you begin this process.
- This plugin requires you to have the [WooCommerce plugin](https://woocommerce.com/) already installed and activated in WordPress.
- Your hosting environment must meet [WooCommerce's minimum requirements](https://docs.woocommerce.com/document/server-requirements), including PHP 7.0 or greater.

Installing from a package

1. In WordPress you can install plugins directly from the admin area.
   Download the plugin to your system, then log in to your WP admin area and go to Plugins > Add New.
   Browse to the plugin archive and select it. Then click Install Now and the plugin will be installed shortly.
2. Activate the plugin.

== Changelog ==

Version 1.0.0 - Initial release of plugin.