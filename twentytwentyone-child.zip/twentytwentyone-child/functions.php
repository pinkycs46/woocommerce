<?php

/*** Child Theme Function  ***/

add_action('wp_enqueue_scripts', 'enqueue_parent_theme_styles');

function enqueue_parent_theme_styles() {
    //wp_enqueue_style('parent-style', get_template_directory_uri() . '/style.css');
    // wp_register_style( 'childstyle', get_template_directory_uri() . '/custom-style.css'  );
    // wp_enqueue_style( 'childstyle' );

  wp_enqueue_style('child-style', get_stylesheet_directory_uri() . '/child-style.css', array(), '1.0', 'all');
}


add_action('init', 'custom_post_type');

function custom_post_type() {
    $labels = array(
        'name'               => _x('Events', 'post type general name', 'your-text-domain'),
        'singular_name'      => _x('Events', 'post type singular name', 'your-text-domain'),
        'menu_name'          => _x('Events', 'admin menu', 'your-text-domain'),
        'name_admin_bar'     => _x('Events', 'add new on admin bar', 'your-text-domain'),
        'add_new'            => _x('Add New', 'custom post', 'your-text-domain'),
        'add_new_item'       => __('Add New Event', 'your-text-domain'),
        'new_item'           => __('New Event', 'your-text-domain'),
        'edit_item'          => __('Edit Event', 'your-text-domain'),
        'view_item'          => __('View Event', 'your-text-domain'),
        'all_items'          => __('All Events', 'your-text-domain'),
        'search_items'       => __('Search Events', 'your-text-domain'),
        'parent_item_colon'  => __('Parent Events:', 'your-text-domain'),
        'not_found'          => __('No custom events found.', 'your-text-domain'),
        'not_found_in_trash' => __('No custom events found in Trash.', 'your-text-domain'),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'menu_icon'          => 'dashicons-calendar',
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( "slug" => "events", "with_front" => true ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 11,     
        'supports'           => array( "title", "editor", "excerpt", "trackbacks", "custom-fields", "comments", "revisions", "thumbnail", "author", "page-attributes", "post-formats" ),
    );

    register_post_type('events', $args);

    $labels = array(
      'name'              => _x( 'Categories', 'taxonomy general name' ),
      'singular_name'     => _x( 'Category', 'taxonomy singular name' ),
      'search_items'      => __( 'Search Category' ),
      'all_items'         => __( 'All Categories' ),
      'parent_item'       => __( 'Parent Category' ),
      'parent_item_colon' => __( 'Parent Category:' ),
      'edit_item'         => __( 'Edit Category' ),
      'update_item'       => __( 'Update Category' ),
      'add_new_item'      => __( 'Add New Category' ),
      'new_item_name'     => __( 'New Category Name' ),
      'menu_name'         => __( 'Category' ),
   );

    $args = array(
      'hierarchical'      => true,
      'labels'            => $labels,
      'show_ui'           => true,
      'show_admin_column' => true,
      'query_var'         => true,
      'rewrite'           => array( 'slug' => 'event_category' ),
   );

   register_taxonomy( 'event_category', array( 'events' ), $args );
}



?>
