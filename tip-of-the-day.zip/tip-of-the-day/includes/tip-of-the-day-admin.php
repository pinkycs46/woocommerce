<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class TipOfTheDayAdmin {
	public static function aw_pl_self_deactivate_notice() {
		/** Display an error message when WooComemrce Plugin is missing **/
		?>
		<div class="notice notice-error">
			<p>Please install and activate WooCommerce plugin before activating Product Labels plugin.</p>
		</div>
		<?php
	}

	public static function aw_pl_save_flash_notice( $notice = '', $type = 'warning', $dismissible = true ) { 
		// Here we return the notices saved on our option, if there are not notices, then an empty array is returned
		$notices = get_option( 'label_flash_notices', array() );
		$dismissible_text = ( $dismissible ) ? 'is-dismissible' : '';

		$notices = array(
						'notice' => $notice, 
						'type' => $type, 
						'dismissible' => $dismissible_text
					); 	
		update_option('label_flash_notices', $notices );
	}
	public static function tip_of_the_day_settings_page() {
		$notice = maybe_unserialize(get_option( 'label_flash_notices'));
		if ( ! empty( $notice ) ) {
			printf('<div class="notice notice-%1$s %2$s"><p>%3$s</p></div>',
			wp_kses($notice['type'], wp_kses_allowed_html('post')),
			wp_kses($notice['dismissible'], wp_kses_allowed_html('post')),
			wp_kses($notice['notice'], wp_kses_allowed_html('post'))
			);
			delete_option( 'label_flash_notices');
		}
		$heading='General Settings';
		?>
		<div class="tab-grid-wrapper">
			<div class="spw-rw clearfix">
				<div class="panel-box product-label-genral-setting">
					<div class="page-title">
						<h2>
						   <?php echo wp_kses($heading, wp_kses_allowed_html('post')); 
						   	 $users = get_users();
						   ?>
						</h2>
						<div class="panel-body">
						   <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" id="rdpl_save_setting_form" enctype="multipart/form-data">
								<?php wp_nonce_field( 'aw_pl_save_setting_form', 'rdpl_save_setting_nonce' ); 
								?>
							  <input type="hidden" name="action" value="aw_pl_save_setting_form">

								<div class="tabcontent rule-general-set" id="genral-setting-tab" style="display: block;">
									<ul>
										<?php 
										if (!empty($users)) {
									        foreach ($users as $user) {
									            ?>
									            <li>
													<label><?php echo $user->display_name; ?></label>
													<div class="control">
						                                <input type="text" name="tip_of_the_day[<?php echo $user->ID; ?>]" class="tip_of_the_day" value="<?php echo get_user_meta($user->ID, 'tip_of_the_day', true); ?>" onkeypress="return checkIt(event, false)" />
						                                <input type="hidden" name="user_id[]" value="<?php echo $user->ID; ?>" />
						                            </div>
												</li>
												<?php
									        }
									    }
										?>
									</ul>
									<div class="submit">
										<input type="submit" class="button button-primary" value="Save" name="pl_label_submit">
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php
	}
	public static function aw_pl_save_setting_form() {
		$url =  admin_url() . 'admin.php?page=tip_of_the_day_settings_page';
		if (isset($_POST['rdpl_save_setting_nonce'])) {
			$aw_pl_new_rule_nonce = sanitize_text_field($_POST['rdpl_save_setting_nonce']);
		}
		if ( !wp_verify_nonce( $aw_pl_new_rule_nonce, 'aw_pl_save_setting_form' )) {
			wp_die('Our Site is protected');
		}

		if (isset($_POST['pl_label_submit'])) {
	        $tip_of_the_day_values = $_POST['tip_of_the_day'];
	        $user_ids = $_POST['user_id'];

	        if (!empty($tip_of_the_day_values) && !empty($user_ids)) {
	            foreach ($user_ids as $index => $user_id) {
	                $tip_of_the_day = sanitize_text_field($tip_of_the_day_values[$user_id]);
	                update_user_meta($user_id, 'tip_of_the_day', $tip_of_the_day);
	            }
	        }
	    }

		self::aw_pl_save_flash_notice( __('General setting is updated'), 'success', true );
		wp_redirect($url);		

	}
	
}	
