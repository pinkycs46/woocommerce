<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class TipOfTheDayPublic {
	public static function display_tip_of_the_day () {

		// show tip of the day value on the center of the header

		$current_user_id = get_current_user_id(); // Get the ID of the currently logged-in user
		$tip_of_the_day = get_user_meta($current_user_id, 'tip_of_the_day', true);

	    if (!empty($tip_of_the_day)) {
	        echo '<div class="tip-of-the-day-header">';
	        echo '<h2>Tip Of the Day</h2>';
	        echo '<p>' . esc_html($tip_of_the_day) . '</p>';
	        echo '</div>';
		} else {
		    // Handle the case when there is no tip of the day set for the user
		    echo 'No tip of the day set for the current user.';
		}
	}
}