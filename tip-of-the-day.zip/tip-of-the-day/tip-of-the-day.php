<?php
/*
* Plugin Name: Tip of the Day
* Description: Display a daily tip set by the admin.
* Version: 1.0
* Author: Your Name
* Requires at least: 5.4.7
* Tested up to: 5.8.1
* WC requires at least: 4.3.3
* WC tested up to: 5.6.0
*/

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

require_once(plugin_dir_path(__FILE__) . 'includes/tip-of-the-day-admin.php');
require_once(plugin_dir_path(__FILE__) . 'includes/tip-of-the-day-public.php');

$tipoftheday = new TipOfTheDay();

/** Present plugin version **/
define( 'TIP_OF_THE DAY_VERSION', '1.0.0' );

class TipOfTheDay {
	public function __construct() {
		/** Constructor function, initialize and register hooks **/
		add_action('admin_init', array(get_called_class(),'aw_product_label_installer'));
		register_uninstall_hook(__FILE__, array(get_called_class(), 'aw_product_label_unistaller'));
		add_action('admin_menu', array(get_called_class(),'add_tip_of_the_day_menu'));

		add_action('admin_enqueue_scripts', array(get_called_class(),'admin_addScript'));
		add_action('wp_enqueue_scripts', array(get_called_class(),'public_addScript'));

		add_action('admin_post_aw_pl_save_setting_form', array('TipOfTheDayAdmin','aw_pl_save_setting_form'));

		// Hook the function to display the tip of the day to a location of your choice, for example, in the footer
		add_action('wp_head', array('TipOfTheDayPublic','display_tip_of_the_day'));
		

	}
	public static function admin_addScript() {
		$path 		= parse_url(get_option('siteurl'), PHP_URL_PATH);
		$host 	 	= parse_url(get_option('siteurl'), PHP_URL_HOST);
		$batc_nonce	= wp_create_nonce('aw_batc_admin_nonce');

		wp_register_style('admincss', plugins_url('/admin/css/admin.css', __FILE__ ), array(), '1.0' );
		wp_enqueue_style('admincss');


		wp_register_script('adminjs', plugins_url('/admin/js/admin.js' , __FILE__ ), array(), '1.0' );
		$js_var = array('site_url' => get_option('siteurl'));
		wp_localize_script('adminjs', 'js_var', $js_var);
		wp_register_script('adminjs', plugins_url('/admin/js/admin.js' , __FILE__ ), array(), '1.0' );
		wp_enqueue_script('adminjs');
	}

	public static function public_addScript() {
		$path 		= parse_url(get_option('siteurl'), PHP_URL_PATH);
		$host 	 	= parse_url(get_option('siteurl'), PHP_URL_HOST);

		/** Add pl CSS and JS files Public Side**/
		wp_register_style('publiccss', plugins_url('/public/css/public.css', __FILE__ ), array(), '1.0' );
		wp_enqueue_style('publiccss');

	}
	public static function aw_product_label_installer() {
		/** Check WooCommerce plugin activated ? **/
		if (is_admin()) {
			wp_deregister_script( 'autosave' );

			global $wpdb;
			$db_label_table_name = $wpdb->prefix . 'table_name'; 

			$charset_collate = $wpdb->get_charset_collate();

			//Check to see if the table exists already, if not, then create it
			
			// if ($wpdb->get_var($wpdb->prepare('SHOW TABLES like %s ' , "{$wpdb->prefix}aw_pl_product_label")) != $db_label_table_name) {
			// 	$sql = "CREATE TABLE {$wpdb->prefix}aw_pl_product_label (
			// 			 `id` int(11) NOT NULL AUTO_INCREMENT,
			// 			 `name` varchar(55) NOT NULL,
			// 			 `position` varchar(55) NOT NULL,
			// 			 `status` int(2) NOT NULL,
			// 			 `type` varchar(55) NOT NULL,
			// 			 `shape_type` varchar(55) DEFAULT NULL,
			// 			 `label_image` text DEFAULT NULL,
			// 			 `label_size` varchar(55) NOT NULL,
			// 			 `label_test_text` varchar(55) NOT NULL,
			// 			 `label_container_css` text NOT NULL,
			// 			 `medium_label_container_css` text NOT NULL,
			// 			 `small_label_container_css` text NOT NULL,
			// 			 `label_text_css` text NOT NULL,
			// 			 `medium_label_text_css` text NOT NULL,
			// 			 `small_label_text_css` text NOT NULL,
			// 			 `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
			// 			 PRIMARY KEY (`id`)
			// 			);";
			// 	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
			// 	dbDelta($sql);
			// }
		}
	}
	public static function aw_product_label_unistaller() {
		/*Perform required operations at time of plugin uninstallation*/
		global $wpdb;
		// Get a list of all users
	    $users = get_users();
	    
	    foreach ($users as $user) {
	        // Remove or reset the user meta value, e.g., 'tip_of_the_day'
	        delete_user_meta($user->ID, 'tip_of_the_day');
	    }
	}
	public static function add_tip_of_the_day_menu() {
		global $submenu;
		if (!empty($_SERVER['HTTP_HOST']) && !empty($_SERVER['REQUEST_URI'])) {
			$host = sanitize_text_field($_SERVER['HTTP_HOST']);
			$request = sanitize_text_field($_SERVER['REQUEST_URI']);
			$current_url='http://' . $host . $request;	
		}
		
		add_menu_page(__('Tip Of the Day', 'main_menu'), __('Tip Of the Day', 'main_menu'), '', 'tip_of_the_day', '', plugin_dir_url(__FILE__) . '/admin/images/tip_of_the_day.png', 25);
		add_submenu_page('tip_of_the_day', __('Settings'), __('Settings'), 'manage_options', 'tip_of_the_day_settings_page', array('TipOfTheDayAdmin' , 'tip_of_the_day_settings_page'));	
	
	}
}


	
