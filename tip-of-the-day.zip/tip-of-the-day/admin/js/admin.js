var nonce_batc  = js_rule_var.aw_batc_nonce;
var url    = js_rule_var.site_url;

function checkIt(evt,allowed = '')
{
	evt = (evt) ? evt : window.event;

	var charCode = (evt.which) ? evt.which : evt.keyCode;

	if(charCode === 46 && allowed == '0')
	{
	return true;	
	}
	if(charCode > 31 && (charCode < 48 || charCode > 57))
	{
	status = "This field accepts numbers only.";
	return false;
	}
	status = "";
	return true;
}




