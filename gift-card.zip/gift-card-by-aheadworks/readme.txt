=== Gift Card By Aheadworks ===
Contributors: Rave Digital
Tags: gift card, woocommerce
Requires at least: 5.2.9
Tested up to: 5.6
Stable tag: trunk
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Gift Card for WooCommerce.

== Description ==

The Gift Card plugin enables Gift Card as a new type of product. With the help of it you can expand your business by increasing sales and attracting new customers via promoting brand awareness. Besides, you will offer your customers a nice gift option to their friends!

== Installation ==

Here are some things to know before you begin this process.
- This plugin requires you to have the [WooCommerce plugin](https://woocommerce.com/) already installed and activated in WordPress.
- Your hosting environment must meet [WooCommerce's minimum requirements](https://docs.woocommerce.com/document/server-requirements), including PHP 7.0 or greater.
- Make sure to update Permalinks under Admin Settings Menu. (Just open Permalinks Page and click "Save Changes" button)

== Changelog ==

Version 1.0.0 - Initial release of plugin.